<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id'])) {
    header('Location: login.php'); // Redirigir a la página de login si no hay sesión
    exit;
}

// Conectar a la base de datos
include('database.php');

// Obtener el id del torneo de la URL
$torneo_id = isset($_GET['torneo_id']) ? intval($_GET['torneo_id']) : 0;

// Verificar si el torneo existe
$sql_torneo = "SELECT * FROM torneos WHERE torneo_id = $torneo_id";
$result_torneo = $conn->query($sql_torneo);

if ($result_torneo->num_rows > 0) {
    $torneo = $result_torneo->fetch_assoc();
    $nombre_torneo = htmlspecialchars($torneo['nombre']); // Escapar caracteres especiales
} else {
    echo "Torneo no encontrado.";
    exit;
}

// Obtener equipos inscritos en el torneo
$sql_equipos = "SELECT * FROM equipos WHERE torneo_id = $torneo_id";
$result_equipos = $conn->query($sql_equipos);

// Obtener ID del usuario actual
$id_usuario = $_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipos en <?php echo $nombre_torneo; ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin: 10px;
            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1);
        }
        .card h2 {
            margin-top: 0;
        }
        .card button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .card button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="ver_torneosuser.php">Volver a Torneos</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <h1>Equipos inscritos en el torneo: <?php echo $nombre_torneo; ?></h1>

        <div class="equipos-container">
            <?php
            if ($result_equipos->num_rows > 0) {
                while ($equipo = $result_equipos->fetch_assoc()) {
                    echo "<div class='card'>";
                    echo "<h2>Equipo: " . htmlspecialchars($equipo['nombre_equipo']) . "</h2>"; // Escapar caracteres especiales

                    // Verificar si el usuario actual es el creador del equipo
                    if ($equipo['usuario_id'] == $id_usuario) {
                        echo "<a href='ver_jugadores.php?equipo_id=" . intval($equipo['equipo_id']) . "'><button>Ver jugadores / Añadir jugadores</button></a>";
                    } else {
                        echo "<a href='ver_jugadores.php?equipo_id=" . intval($equipo['equipo_id']) . "'><button>Ver jugadores</button></a>";
                    }

                    echo "</div>";
                }
            } else {
                echo "<p>No hay equipos inscritos en este torneo.</p>";
            }
            ?>
        </div>
    </main>

    <?php $conn->close(); ?>
</body>
</html>
