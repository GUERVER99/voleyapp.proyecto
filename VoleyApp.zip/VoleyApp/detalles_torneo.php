<?php
include('database.php'); // Conectar a la base de datos

// Obtener el ID del torneo de la URL
$torneo_id = $_GET['torneo_id'];

// Consulta para obtener los detalles del torneo
$query_torneo = "SELECT nombre, fecha_inicio, fecha_fin, descripcion FROM torneos WHERE id = '$torneo_id'";
$result_torneo = $conn->query($query_torneo);

// Verificar si se encontró el torneo
if ($result_torneo->num_rows == 0) {
    die("Torneo no encontrado.");
}

$torneo = $result_torneo->fetch_assoc();

// Consulta para obtener los equipos inscritos en el torneo
$query_equipos = "SELECT id, nombre FROM equipos WHERE torneo_id = '$torneo_id'";
$result_equipos = $conn->query($query_equipos);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Torneo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <a href="index.php" class="navbar-brand">Torneos de Voleibol</a>
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="crear_partido.php" class="nav-link">Partidos</a></li>
                    <li class="nav-item"><a href="home.php" class="navbar-brand">Inicio</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Detalles del Torneo: <?php echo $torneo['nombre']; ?></h1>
        <p><strong>Fecha de Inicio:</strong> <?php echo $torneo['fecha_inicio']; ?></p>
        <p><strong>Fecha de Fin:</strong> <?php echo $torneo['fecha_fin']; ?></p>
        <p><strong>Descripción:</strong> <?php echo $torneo['descripcion']; ?></p>

        <h2>Equipos Inscritos</h2>
        <div class="cards-container">
            <?php if ($result_equipos->num_rows > 0): ?>
                <?php while ($equipo = $result_equipos->fetch_assoc()): ?>
                    <div class="card">
                        <h3><?php echo $equipo['nombre']; ?></h3>
                        <a href="equipos.php?equipo_id=<?php echo $equipo['id']; ?>" class="card-link">Ver Jugadores</a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No hay equipos inscritos en este torneo.</p>
            <?php endif; ?>
        </div>

        <a href="ver_torneos.php">Volver a Ver Torneos</a>
    </main>

    <?php
    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>
