<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener todos los torneos
$sql_torneos = "SELECT * FROM torneos";
$result_torneos = $conn->query($sql_torneos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Torneos</title>
    <link rel="stylesheet" href="nav.css"> <!-- Estilos opcionales -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 10px;
            padding: 15px;
            width: 300px; /* Ajusta el ancho de las tarjetas */
            text-align: center;
        }
        .btn-modificar {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 12px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-modificar:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>TORNEOS</h1>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="admin_dashboard.php" class="navbar-brand">Inicio</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="admin_posiciones.php" class="nav-link">Posiciones</a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container">
        <?php
        if ($result_torneos->num_rows > 0) {
            while ($torneo = $result_torneos->fetch_assoc()) {
                echo "<div class='card'>";
                echo "<h2>Torneo: " . htmlspecialchars($torneo['nombre']) . "</h2>";
                echo "<p>Fecha de inicio: " . htmlspecialchars($torneo['fecha_inicio']) . "</p>";
                echo "<p>Fecha de fin: " . htmlspecialchars($torneo['fecha_fin']) . "</p>";
                
                // Botón de modificar
                echo "<a href='modificar_torneos.php?id=" . $torneo['torneo_id'] . "' class='btn-modificar'>Modificar Torneo</a>";

                // Obtener los equipos de cada torneo usando torneo_id
                $torneo_id = $torneo['torneo_id'];
                $sql_equipos = "SELECT * FROM equipos WHERE torneo_id = $torneo_id"; 
                $result_equipos = $conn->query($sql_equipos);

                if ($result_equipos->num_rows > 0) {
                    echo "<h3>Equipos inscritos:</h3>";
                    echo "<ul>";
                    while ($equipo = $result_equipos->fetch_assoc()) {
                        echo "<li>" . htmlspecialchars($equipo['nombre_equipo']) . "</li>"; 

                        // Obtener los jugadores de cada equipo usando equipo_id
                        $equipo_id = $equipo['equipo_id'];
                        $sql_jugadores = "SELECT * FROM jugadores WHERE equipo_id = $equipo_id"; 
                        $result_jugadores = $conn->query($sql_jugadores);

                        if ($result_jugadores->num_rows > 0) {
                            echo "<ul>";
                            while ($jugador = $result_jugadores->fetch_assoc()) {
                                echo "<li>Jugador: " . htmlspecialchars($jugador['nombre']) . " - Posición: " . htmlspecialchars($jugador['posicion']) . "</li>";
                            }
                            echo "</ul>";
                        } else {
                            echo "<ul><li>No hay jugadores registrados en este equipo.</li></ul>";
                        }
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No hay equipos registrados en este torneo.</p>";
                }
                echo "</div>"; // Cierra la tarjeta
            }
        } else {
            echo "<p>No hay torneos registrados.</p>";
        }

        $conn->close();
        ?>
    </div>

    <a href="admin_dashboard.php">Volver al Panel de Administración</a>
</body>
</html>
