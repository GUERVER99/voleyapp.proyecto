<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Partido</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Crear Partido Nuevo</h1>
    </header>

    <section class="crear-partido">
        <form action="procesar_partido.php" method="POST">
            <label for="equipo_local">Equipo Local:</label>
            <select name="equipo_local" id="equipo_local" required>
                <?php
                // Conectar a la base de datos
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "torneos_volley";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Obtener los equipos
                $sql = "SELECT id, nombre FROM equipos";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                    }
                }

                $conn->close();
                ?>
            </select>

            <label for="equipo_visitante">Equipo Visitante:</label>
            <select name="equipo_visitante" id="equipo_visitante" required>
                <?php
                // Conectar a la base de datos de nuevo para visitantes
                $conn = new mysqli($servername, $username, $password, $dbname);

                $sql = "SELECT id, nombre FROM equipos";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                    }
                }

                $conn->close();
                ?>
            </select>

            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>

            <label for="hora">Hora:</label>
            <input type="time" id="hora" name="hora" required>

            <label for="grupo">Grupo:</label>
            <input type="number" id="grupo" name="grupo" min="1" required>

            <input type="submit" value="Crear Partido">
        </form>
    </section>
</body>
</html>
