<?php
// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$equipo_local = $_POST['equipo_local'];
$equipo_visitante = $_POST['equipo_visitante'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$grupo = $_POST['grupo'];

// Insertar partido en la base de datos
$sql = "INSERT INTO partidos (equipo_local, equipo_visitante, fecha, hora, grupo, estado) VALUES ('$equipo_local', '$equipo_visitante', '$fecha', '$hora', '$grupo', 'Pendiente')";

if ($conn->query($sql) === TRUE) {
    echo "Partido creado exitosamente.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
