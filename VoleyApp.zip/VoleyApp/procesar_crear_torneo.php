<?php
// Conexión a la base de datos
$host = 'localhost'; // Cambia esto si tu base de datos no está en localhost
$dbname = 'torneos_volley'; // Cambia esto al nombre de tu base de datos
$username = 'root'; // Cambia esto a tu usuario de base de datos
$password = ''; // Cambia esto a tu contraseña de base de datos

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Comprobar si se envió el formulario
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_POST['nombre'];
        $fecha_inicio = $_POST['fecha_inicio'];
        $fecha_fin = $_POST['fecha_fin'];
        
        // Procesar la imagen
        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == UPLOAD_ERR_OK) {
            // Leer el contenido del archivo
            $imagen = file_get_contents($_FILES['imagen']['tmp_name']);
            $imagenBlob = $imagen; // Guardar imagen como BLOB

            // Consulta para insertar el torneo
            $stmt = $pdo->prepare("INSERT INTO torneos (nombre, fecha_inicio, fecha_fin, imagen) VALUES (:nombre, :fecha_inicio, :fecha_fin, :imagen)");
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':fecha_inicio', $fecha_inicio);
            $stmt->bindParam(':fecha_fin', $fecha_fin);
            $stmt->bindParam(':imagen', $imagenBlob, PDO::PARAM_LOB); // Asegurarse de que el tipo sea BLOB
            
            // Ejecutar la consulta
            if ($stmt->execute()) {
                echo "Torneo creado exitosamente.";
            } else {
                echo "Error al crear el torneo.";
            }
        } else {
            echo "Error al subir la imagen.";
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
