<?php
session_start();
// Verificar si el usuario es administrador
if (!isset($_SESSION['nombre']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <style>
        /* General */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Encabezado */
        header {
            background-color: #007bff;
            padding: 20px;
            text-align: center;
            color: white;
        }

        h1 {
            margin: 0;
            font-size: 2.2em;
            font-weight: normal;
        }

        /* Navegación */
        nav {
            margin-top: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            font-size: 1.1em;
            padding: 10px 20px;
            background-color: #0056b3;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #004080;
        }

        nav ul li a:active {
            background-color: #003366;
        }

        /* Estilos para el cuerpo principal */
        h1 {
            text-align: center;
            margin-top: 40px;
        }

        /* Estilos de la tabla */
        table {
            width: 80%;
            margin: 40px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        tr:hover {
            background-color: #e2e2e2;
        }

        /* Botones dentro de la tabla */
        table a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        table a:hover {
            color: #004080;
        }

        /* Estilos para el pie de página */
        footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bienvenido, Administrador <?php echo $_SESSION['nombre']; ?></h1>
        <nav>
            <ul>
                <li><a href="crear_torneo.php">Crear Torneo</a></li>
                <li><a href="admin_torneos.php">Ver torneos</a></li>
                <li><a href="gestionar_equipos.php">Gestionar Equipos</a></li>
                <li><a href="ver_partidos.php">Partidos</a></li>
                <li><a href="subir_resultado.php">Subir Resultados</a></li>
                <li><a href="gestionar_usuarios.php">Gestionar Usuarios</a></li>
                <li><a href="index.php">Salir</a></li> <!-- Enlace para salir -->
            </ul>
        </nav>
    </header>

    <!-- Si necesitas agregar tablas aquí, usará los estilos proporcionados para las tablas -->

    <footer>
        <p>© 2024 Sistema de Torneos de Voleibol</p>
    </footer>
</body>
</html>
