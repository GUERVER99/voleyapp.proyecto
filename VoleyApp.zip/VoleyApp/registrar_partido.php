<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Partido</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="ver_torneos.php" class="nav-link">Torneos</a></li>
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="calendario.php" class="nav-link">Calendario</a></li>
                    <li class="nav-item"><a href="posiciones.php" class="nav-link">Posiciones</a></li>
                </ul>
            </div>
        </nav>
        <h1>Registrar Resultado de Partido</h1>
    </header>

    <section>
        <form action="guardar_partido.php" method="post">
            <label for="equipo_local">Equipo Local:</label>
            <select name="equipo_local" id="equipo_local" required>
                <?php
                $conn = new mysqli('localhost', 'root', '', 'torneos_volley');
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                $sql = "SELECT id, nombre FROM equipos";
                $result = $conn->query($sql);

                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                }
                $conn->close();
                ?>
            </select>

            <label for="equipo_visitante">Equipo Visitante:</label>
            <select name="equipo_visitante" id="equipo_visitante" required>
                <?php
                $conn = new mysqli('localhost', 'root', '', 'torneos_volley');
                $sql = "SELECT id, nombre FROM equipos";
                $result = $conn->query($sql);

                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                }
                $conn->close();
                ?>
            </select>

            <label for="sets_local">Sets Local:</label>
            <input type="number" name="sets_local" id="sets_local" min="0" max="5" required>

            <label for="sets_visitante">Sets Visitante:</label>
            <input type="number" name="sets_visitante" id="sets_visitante" min="0" max="5" required>

            <label for="fecha">Fecha:</label>
            <input type="date" name="fecha" id="fecha" required>

            <label for="hora">Hora:</label>
            <input type="time" name="hora" id="hora" required>

            <button type="submit">Guardar Resultado</button>
        </form>
    </section>

    <footer>
        <p>&copy; 2024 Dusport - Fedevolei Colombia</p>
    </footer>
</body>
</html>
