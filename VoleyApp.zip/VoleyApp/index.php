<?php
session_start();

// Parámetros de conexión a la base de datos
$host = 'localhost';
$dbname = 'torneos_volley';
$username = 'root';
$password = '';

try {
    // Crear una conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Consulta para obtener los torneos
    $stmt = $pdo->query("SELECT nombre, imagen FROM torneos");

    // Fetch todos los torneos
    $torneos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Si se envía el formulario de login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Conectar a la base de datos
    $conn = new mysqli('localhost', 'root', '', 'torneos_volley');
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Verificar el usuario
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Verificar la contraseña
        if (password_verify($password, $user['password'])) {
            // Guardar el rol en la sesión
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['rol'] = $user['rol'];

            // Redirigir según el rol del usuario
            if ($user['rol'] == 'admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: home.php");
            }
            exit;
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "El usuario no existe.";
    }

    $stmt->close();
    $conn->close();
}

// Asegúrate de que la variable $torneos esté definida antes de usarla
if (!isset($torneos) || !is_array($torneos)) {
    $torneos = [];
}

// Función para convertir el BLOB en base64
function blobToBase64($blob) {
    return 'data:image/jpeg;base64,' . base64_encode($blob);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Torneos de Voleibol</title>
    <link rel="stylesheet" href="index.css">
    <style>
        /* Estilos adicionales para el login desplegable */
        .login-dropdown {
            display: none;
            position: absolute;
            top: 100px; /* Ajusta la posición para que esté centrado */
            right: 10px;
            background-color: rgba(255, 255, 255, 0.9); /* Fondo semitransparente */
            border: 1px solid #ccc;
            padding: 20px;
            width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000; /* Asegúrate de que esté por encima de otros elementos */
        }
        .login-dropdown.active {
            display: block;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            background-color: #333;
            padding: 10px;
            position: relative; /* Asegúrate de que la navbar tenga posición relativa */
            z-index: 10; /* Colocar por encima del carrusel */
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 14px 20px;
        }
        .navbar a:hover {
            background-color: #575757;
        }
        .error {
            color: red;
        }
        .hero {
            position: relative; /* Asegúrate de que el contenedor del carrusel sea relativo */
        }
        .hero-image {
            width: 100%; /* Asegúrate de que la imagen ocupe todo el ancho */
            display: none; /* Ocultar todas las imágenes inicialmente */
        }
        .hero-image.active {
            display: block; /* Mostrar la imagen activa */
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h1 style="color:white;">FEDEVOLEY COL</h1>
            <a href="#" id="login-btn">Iniciar sesión</a>
        </div>
    </header>

    <!-- Formulario de login desplegable -->
    <div id="login-dropdown" class="login-dropdown">
        <h2>Iniciar sesión</h2>
        <form method="POST" action="">
            <label for="email">Correo electrónico:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" class="btn">Iniciar sesión</button>
            
            <!-- Mostrar error si existe -->
            <?php if (isset($error)): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
        </form>
    </div>

    <main>
        <section class="hero">
            <!-- Carrusel de imágenes -->
            <img src="portada.jpg" alt="Imagen 1" class="hero-image active">
            <img src="portada_2.jpg" alt="Imagen 2" class="hero-image">
            <img src="portada_3.jpg" alt="Imagen 3" class="hero-image">
        </section>

        <section class="torneos">
            <h2>Torneos en Curso</h2>
            <div class="torneos-carousel">
                <?php foreach ($torneos as $torneo): ?>
                    <div class="torneo-item">
                        <img src="<?php echo blobToBase64($torneo['imagen']); ?>" alt="<?php echo htmlspecialchars($torneo['nombre']); ?>" class="torneo-imagen">
                        <h3><?php echo htmlspecialchars($torneo['nombre']); ?></h3>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer>
        <ul>
            <li><a href="https://facebook.com" target="_blank">Facebook</a></li>
            <li><a href="https://twitter.com" target="_blank">Twitter</a></li>
            <li><a href="https://instagram.com" target="_blank">Instagram</a></li>
        </ul>
        <p>&copy; <?php echo date("Y"); ?> Nombre de la Empresa. Todos los derechos reservados.</p>
    </footer>

    <script>
        // JavaScript para mostrar/ocultar el formulario de login
        document.getElementById('login-btn').addEventListener('click', function(event) {
            event.preventDefault(); // Evita que el enlace recargue la página
            const loginDropdown = document.getElementById('login-dropdown');
            loginDropdown.classList.toggle('active'); // Muestra o oculta el formulario
        });

        // JavaScript para el carrusel de imágenes
        let currentIndex = 0;
        const images = document.querySelectorAll('.hero-image');
        
        function showNextImage() {
            images[currentIndex].classList.remove('active');
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].classList.add('active');
        }

        setInterval(showNextImage, 3000);

        // Carrusel de torneos
        let torneoIndex = 0;
        const torneoItems = document.querySelectorAll('.torneo-item');

        function showNextTorneo() {
            torneoItems[torneoIndex].style.display = 'none';
            torneoIndex = (torneoIndex + 1) % torneoItems.length;
            torneoItems[torneoIndex].style.display = 'block';
        }

        torneoItems.forEach((item, index) => {
            item.style.display = index === 0 ? 'block' : 'none';
        });

        setInterval(showNextTorneo, 5000);
    </script>
</body>
</html>
