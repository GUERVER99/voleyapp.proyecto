<?php
session_start();
// Verificar si el usuario es administrador
if (!isset($_SESSION['nombre']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del partido desde la URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $partido_id = intval($_GET['id']);
} else {
    die("ID del partido no proporcionado.");
}

// Obtener los datos del partido
$sql = "SELECT * FROM partidos WHERE partido_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $partido_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $partido = $result->fetch_assoc();
} else {
    die("Partido no encontrado.");
}

// Obtener la lista de torneos
$sql_torneos = "SELECT torneo_id, nombre FROM torneos";
$result_torneos = $conn->query($sql_torneos);

// Obtener la lista de equipos
$sql_equipos = "SELECT equipo_id, nombre_equipo FROM equipos";
$result_equipos = $conn->query($sql_equipos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Resultado</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Subir Resultado del Partido</h1>
    </header>

    <!-- Navbar -->
    <nav>
        <ul>
            <li><a href="admin_dashboard.php">Volver al Dashboard</a></li>
            <li><a href="logout.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
    <!-- Fin del Navbar -->

    <section class="subir-resultado">
        <form action="" method="POST">
            <input type="hidden" name="partido_id" value="<?php echo $partido['partido_id']; ?>">

            <label for="torneo">Seleccionar Torneo:</label>
            <select name="torneo_id" id="torneo" required>
                <?php while ($torneo = $result_torneos->fetch_assoc()): ?>
                    <option value="<?php echo $torneo['torneo_id']; ?>"><?php echo $torneo['nombre']; ?></option>
                <?php endwhile; ?>
            </select>

            <label for="equipo_local">Equipo Local:</label>
            <select name="equipo_local_id" id="equipo_local" required>
                <?php while ($equipo = $result_equipos->fetch_assoc()): ?>
                    <option value="<?php echo $equipo['equipo_id']; ?>"><?php echo $equipo['nombre_equipo']; ?></option>
                <?php endwhile; ?>
            </select>

            <label for="equipo_visitante">Equipo Visitante:</label>
            <select name="equipo_visitante_id" id="equipo_visitante" required>
                <?php $result_equipos->data_seek(0); // Reiniciar el puntero ?>
                <?php while ($equipo = $result_equipos->fetch_assoc()): ?>
                    <option value="<?php echo $equipo['equipo_id']; ?>"><?php echo $equipo['nombre_equipo']; ?></option>
                <?php endwhile; ?>
            </select>

            <label for="sets_local">Sets Local:</label>
            <input type="number" name="sets_local" id="sets_local" required min="0">

            <label for="sets_visitante">Sets Visitante:</label>
            <input type="number" name="sets_visitante" id="sets_visitante" required min="0">

            <button type="submit">Subir Resultados</button>
        </form>

        <?php
        // Procesar el formulario al enviarlo
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $partido_id = $_POST['partido_id'];
            $sets_local = intval($_POST['sets_local']);
            $sets_visitante = intval($_POST['sets_visitante']);

            // Validar que los equipos sean diferentes
            if ($_POST['equipo_local_id'] == $_POST['equipo_visitante_id']) {
                echo "<p>El equipo local y visitante no pueden ser el mismo.</p>";
            } else {
                // Actualizar el resultado del partido
                $sql_update = "UPDATE partidos SET sets_local = ?, sets_visitante = ?, estado = 'Finalizado' WHERE partido_id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("iii", $sets_local, $sets_visitante, $partido_id);

                if ($stmt_update->execute()) {
                    echo "<p>Resultados actualizados correctamente.</p>";

                    // Actualizar la tabla de posiciones
                    if ($sets_local > $sets_visitante) {
                        // Equipo local gana
                        $sql_update_puntos = "UPDATE equipos SET puntos = puntos + 3 WHERE equipo_id = ?";
                        $stmt_ganador = $conn->prepare($sql_update_puntos);
                        $stmt_ganador->bind_param("i", $_POST['equipo_local_id']);
                        $stmt_ganador->execute();
                        $stmt_ganador->close();
                    } elseif ($sets_local < $sets_visitante) {
                        // Equipo visitante gana
                        $sql_update_puntos = "UPDATE equipos SET puntos = puntos + 3 WHERE equipo_id = ?";
                        $stmt_ganador = $conn->prepare($sql_update_puntos);
                        $stmt_ganador->bind_param("i", $_POST['equipo_visitante_id']);
                        $stmt_ganador->execute();
                        $stmt_ganador->close();
                    } else {
                        // Empate
                        $sql_update_puntos_local = "UPDATE equipos SET puntos = puntos + 1 WHERE equipo_id = ?";
                        $sql_update_puntos_visitante = "UPDATE equipos SET puntos = puntos + 1 WHERE equipo_id = ?";
                        
                        $stmt_local = $conn->prepare($sql_update_puntos_local);
                        $stmt_local->bind_param("i", $_POST['equipo_local_id']);
                        $stmt_local->execute();
                        $stmt_local->close();
                        
                        $stmt_visitante = $conn->prepare($sql_update_puntos_visitante);
                        $stmt_visitante->bind_param("i", $_POST['equipo_visitante_id']);
                        $stmt_visitante->execute();
                        $stmt_visitante->close();
                    }
                } else {
                    echo "<p>Error al actualizar resultados: " . $conn->error . "</p>";
                }
            }
        }
        ?>
    </section>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
