<?php
session_start();

// Conectar a la base de datos
include('database.php');

// Obtener los datos del formulario
$equipo_id = $_POST['equipo_id'];
$nombre = $_POST['nombre'];
$tipo_documento = $_POST['tipo_documento'];
$documento = $_POST['documento'];
$posicion = $_POST['posicion'];

// Insertar el nuevo jugador en la base de datos
$sql_insert = "INSERT INTO jugadores (equipo_id, nombre, tipo_documento, documento, posicion) 
               VALUES ($equipo_id, '$nombre', '$tipo_documento', '$documento', '$posicion')";

if ($conn->query($sql_insert) === TRUE) {
    // Redirigir de nuevo a la página de jugadores del equipo
    header("Location: ver_jugadores.php?equipo_id=$equipo_id");
    exit;
} else {
    echo "Error al agregar jugador: " . $conn->error;
}

$conn->close();
?>
