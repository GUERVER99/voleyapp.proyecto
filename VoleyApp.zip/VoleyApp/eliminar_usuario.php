<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID del usuario a eliminar
$userId = $_GET['id'];

// Eliminar el usuario de la base de datos
$sql = "DELETE FROM usuarios WHERE id = $userId";

if ($conn->query($sql) === TRUE) {
    echo "Usuario eliminado correctamente.";
} else {
    echo "Error al eliminar el usuario: " . $conn->error;
}

$conn->close();

// Redirigir de vuelta a la página de gestión de usuarios
header("Location: gestionar_usuarios.php");
exit;
?>
