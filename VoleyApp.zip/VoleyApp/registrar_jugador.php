<?php
include('database.php'); // Conectar a la base de datos

// Obtener el ID del equipo desde la URL
$equipo_id = isset($_GET['equipo_id']) ? $_GET['equipo_id'] : '';

// Consulta para obtener todos los equipos (si es necesario)
$query = "SELECT id, nombre FROM equipos";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Jugador</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="equipos.php" class="nav-link">Ver Equipos</a></li>
                    <li class="nav-item"><a href="ver_torneos.php" class="nav-link">Ver Torneos</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Registrar Nuevo Jugador</h1>
        <form action="procesar_registrar_jugador.php" method="POST">
            <label for="equipo_id">Seleccionar Equipo:</label>
            <select id="equipo_id" name="equipo_id" required>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $selected = ($row['id'] == $equipo_id) ? 'selected' : '';
                        echo "<option value='" . $row['id'] . "' $selected>" . $row['nombre'] . "</option>";
                    }
                } else {
                    echo "<option value=''>No hay equipos disponibles</option>";
                }
                ?>
            </select>
            <br>
            <label for="nombre">Nombre del Jugador:</label>
            <input type="text" id="nombre" name="nombre" required>
            <br>
            <label for="documento_identidad">Número de Identidad:</label>
            <input type="text" id="documento_identidad" name="documento_identidad" required>
            <br>
            <label for="posicion">Posición:</label>
            <input type="text" id="posicion" name="posicion" required>
            <br>
            <button type="submit">Registrar Jugador</button>
        </form>
    </main>

    <?php
    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>
