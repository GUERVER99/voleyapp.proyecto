<?php
include('database.php'); // Conectar a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $equipo_id = $_POST['equipo_id']; // Capturando el equipo_id del formulario
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $documento_identidad = mysqli_real_escape_string($conn, $_POST['documento_identidad']);
    $posicion = mysqli_real_escape_string($conn, $_POST['posicion']);

    // Verificar si ya existe un jugador con el mismo número de identidad
    $check_query = "SELECT * FROM jugadores WHERE documento_identidad = '$documento_identidad'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        // Si el jugador ya existe, no se inserta y se muestra un mensaje de error
        $message = "Error: Ya existe un jugador con el documento de identidad '$documento_identidad'.";
    } else {
        // Consulta SQL para insertar un nuevo jugador
        $query = "INSERT INTO jugadores (equipo_id, nombre, documento_identidad, posicion) 
                  VALUES ('$equipo_id', '$nombre', '$documento_identidad', '$posicion')";

        if ($conn->query($query) === TRUE) {
            $message = "Jugador registrado exitosamente.";
        } else {
            $message = "Error: " . $conn->error;
        }
    }

    // Cerrar la conexión
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de Registro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="equipos.php" class="nav-link">Ver Equipos</a></li>
                    <li class="nav-item"><a href="ver_torneos.php" class="nav-link">Ver Torneos</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Resultado del Registro</h1>
        <p><?php echo $message; ?></p>
        <a href="registrar_jugador.php?equipo_id=<?php echo $equipo_id; ?>">Registrar Otro Jugador</a> | 
        <a href="equipos.php">Ver Todos los Equipos</a> | 
        <a href="home.html">Volver a la Página Principal</a>
    </main>
</body>
</html>
