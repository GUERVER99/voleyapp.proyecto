<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar Tabla de Posiciones</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        h1 {
            margin: 0;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: #444;
        }

        .navbar-nav {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        .navbar-nav li {
            display: inline;
        }

        .navbar-nav li a {
            color: #fff;
            text-decoration: none;
            padding: 14px 20px;
            display: inline-block;
        }

        .navbar-nav li a:hover {
            background-color: #555;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .tabla-posiciones {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 900px;
        }

        .tabla-posiciones form {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .tabla-posiciones label {
            font-weight: bold;
        }

        .tabla-posiciones select {
            padding: 5px;
            font-size: 16px;
            margin-left: 10px;
        }

        .tabla-posiciones button {
            padding: 8px 16px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .tabla-posiciones button:hover {
            background-color: #555;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #333;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background-color: #333;
            color: #fff;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        @media (max-width: 768px) {
            .tabla-posiciones {
                padding: 10px;
            }

            .tabla-posiciones form {
                flex-direction: column;
                align-items: flex-start;
            }

            .tabla-posiciones select, .tabla-posiciones button {
                margin-top: 10px;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="admin_dashboard.php" class="navbar-brand">Inicio </a></li>
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="actualizar_resultado.php" class="nav-link">Actualizar Resultado</a></li>
                    <li class="nav-item"><a href="index.php" class="navbar-brand">Salir</a></li>
                </ul>
            </div>
        </nav>
        <h1>Administrar Tabla de Posiciones</h1>
    </header>

    <section class="tabla-posiciones">
        <form method="GET" action="">
            <label for="torneo">Seleccionar Torneo:</label>
            <select name="torneo_id" id="torneo" required>
                <?php
                // Conexión a la base de datos
                $servername = "localhost"; 
                $username = "root"; 
                $password = ""; 
                $dbname = "torneos_volley"; 

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Obtener torneos
                $sql_torneos = "SELECT torneo_id, nombre FROM torneos";
                $result_torneos = $conn->query($sql_torneos);

                if ($result_torneos->num_rows > 0) {
                    while ($torneo = $result_torneos->fetch_assoc()) {
                        echo "<option value='" . htmlspecialchars($torneo['torneo_id']) . "'>" . htmlspecialchars($torneo['nombre']) . "</option>";
                    }
                } else {
                    echo "<option value=''>No hay torneos disponibles</option>";
                }

                $conn->close();
                ?>
            </select>
            <button type="submit">Ver Tabla de Posiciones</button>
        </form>

        <table border="1">
            <thead>
                <tr>
                    <th>Equipo</th>
                    <th>Partidos Jugados</th>
                    <th>Partidos Ganados</th>
                    <th>Partidos Perdidos</th>
                    <th>Sets Ganados</th>
                    <th>Sets Perdidos</th>
                    <th>Diferencia de Sets</th>
                    <th>Puntos</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Reabrimos la conexión para mostrar las posiciones
                if (isset($_GET['torneo_id']) && !empty($_GET['torneo_id'])) {
                    $torneo_id = $_GET['torneo_id'];

                    // Crear conexión
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Conexión fallida: " . $conn->connect_error);
                    }

                    // Obtener equipos asociados al torneo seleccionado
                    $sql = "SELECT equipo_id, nombre_equipo FROM equipos WHERE torneo_id = ?";
                    $stmt_equipo = $conn->prepare($sql);
                    $stmt_equipo->bind_param("i", $torneo_id);
                    $stmt_equipo->execute();
                    $result_equipos = $stmt_equipo->get_result();

                    if ($result_equipos->num_rows > 0) {
                        while ($equipo = $result_equipos->fetch_assoc()) {
                            $equipo_id = $equipo['equipo_id'];
                            $equipo_nombre = $equipo['nombre_equipo'];

                            // Inicializar datos de la tabla
                            $partidos_jugados = 0;
                            $partidos_ganados = 0;
                            $partidos_perdidos = 0;
                            $sets_ganados = 0;
                            $sets_perdidos = 0;
                            $puntos = 0;

                            // Consultar partidos como local
                            $sql_local = "SELECT sets_local, sets_visitante FROM partidos WHERE equipo_local_id = ? AND torneo_id = ?";
                            $stmt_local = $conn->prepare($sql_local);
                            $stmt_local->bind_param("ii", $equipo_id, $torneo_id);
                            $stmt_local->execute();
                            $result_local = $stmt_local->get_result();

                            while ($partido = $result_local->fetch_assoc()) {
                                $sets_local = $partido['sets_local'];
                                $sets_visitante = $partido['sets_visitante'];
                                $partidos_jugados++;

                                // Calcular el resultado
                                if ($sets_local > $sets_visitante) {
                                    $partidos_ganados++;
                                    $puntos += ($sets_local == 3 && $sets_visitante < 2) ? 3 : 2;
                                } else {
                                    $partidos_perdidos++;
                                    $puntos += ($sets_local == 2 && $sets_visitante == 3) ? 1 : 0;
                                }

                                $sets_ganados += $sets_local;
                                $sets_perdidos += $sets_visitante;
                            }
                            $stmt_local->close();

                            // Consultar partidos como visitante
                            $sql_visitante = "SELECT sets_local, sets_visitante FROM partidos WHERE equipo_visitante_id = ? AND torneo_id = ?";
                            $stmt_visitante = $conn->prepare($sql_visitante);
                            $stmt_visitante->bind_param("ii", $equipo_id, $torneo_id);
                            $stmt_visitante->execute();
                            $result_visitante = $stmt_visitante->get_result();

                            while ($partido = $result_visitante->fetch_assoc()) {
                                $sets_local = $partido['sets_local'];
                                $sets_visitante = $partido['sets_visitante'];
                                $partidos_jugados++;

                                // Calcular el resultado
                                if ($sets_visitante > $sets_local) {
                                    $partidos_ganados++;
                                    $puntos += ($sets_visitante == 3 && $sets_local < 2) ? 3 : 2;
                                } else {
                                    $partidos_perdidos++;
                                    $puntos += ($sets_visitante == 2 && $sets_local == 3) ? 1 : 0;
                                }

                                $sets_ganados += $sets_visitante;
                                $sets_perdidos += $sets_local;
                            }
                            $stmt_visitante->close();

                            // Calcular la diferencia de sets
                            $diferencia_sets = $sets_ganados - $sets_perdidos;

                            // Mostrar fila en la tabla
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($equipo_nombre) . "</td>";
                            echo "<td>" . $partidos_jugados . "</td>";
                            echo "<td>" . $partidos_ganados . "</td>";
                            echo "<td>" . $partidos_perdidos . "</td>";
                            echo "<td>" . $sets_ganados . "</td>";
                            echo "<td>" . $sets_perdidos . "</td>";
                            echo "<td>" . $diferencia_sets . "</td>";
                            echo "<td>" . $puntos . "</td>";
                            echo "<td><a href='editar_equipo.php?equipo_id=" . $equipo_id . "'>Editar</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No hay equipos en este torneo</td></tr>";
                    }

                    $conn->close();
                } else {
                    echo "<tr><td colspan='9'>Seleccione un torneo para ver la tabla de posiciones</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>

    <footer>
        <p>© 2024 Sistema de Torneos de Voleibol</p>
    </footer>
</body>
</html>
