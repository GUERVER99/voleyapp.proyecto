<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Verificar si se ha pasado un ID de usuario
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID de usuario no proporcionado.";
    exit;
}

$userId = intval($_GET['id']); // Asegurarse de que el ID sea un entero

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$nombre = "";
$email = "";
$rol = "";

// Manejar la actualización del usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $rol = $_POST['rol'];

    // Validar los datos
    if (empty($nombre) || empty($email) || empty($rol)) {
        $error = "Todos los campos son obligatorios.";
    } else {
        // Actualizar el usuario en la base de datos usando consultas preparadas
        $sql = "UPDATE usuarios SET nombre = ?, email = ?, rol = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die("Error en la preparación de la consulta: " . $conn->error);
        }
        $stmt->bind_param("sssi", $nombre, $email, $rol, $userId);

        if ($stmt->execute()) {
            echo "Usuario actualizado correctamente.";
            header("Location: gestionar_usuarios.php");
            exit;
        } else {
            $error = "Error al actualizar el usuario: " . $stmt->error;
        }

        $stmt->close();
    }
} else {
    // Obtener los datos actuales del usuario para mostrarlos en el formulario
    $sql = "SELECT nombre, email, rol FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conn->error);
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($nombre, $email, $rol);
    if ($stmt->fetch()) {
        // Datos obtenidos correctamente
    } else {
        echo "Usuario no encontrado.";
        exit;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="style.css"> <!-- Añade tus propios estilos -->
</head>
<body>
    <header>
        <h1>Editar Usuario</h1>
    </header>

    <section class="editar-usuario">
        <?php
        if (isset($error)) {
            echo "<p style='color:red;'>$error</p>";
        }
        ?>
        <form action="" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br>

            <label for="rol">Rol:</label>
            <select name="rol" id="rol" required>
                <option value="usuario" <?php if ($rol == 'usuario') echo 'selected'; ?>>Usuario</option>
                <option value="admin" <?php if ($rol == 'admin') echo 'selected'; ?>>Administrador</option>
            </select><br>

            <input type="submit" value="Actualizar Usuario">
        </form>
    </section>

    <footer>
        <p>&copy; 2024 Dusport - Fedevolei Colombia</p>
    </footer>
</body>
</html>
