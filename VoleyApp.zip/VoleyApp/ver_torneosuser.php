<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id'])) {
    header('Location: login.php'); // Redirigir a la página de login si no hay sesión
    exit;
}

// Incluir la conexión a la base de datos
include('database.php');

// Obtener todos los torneos
$sql_torneos = "SELECT * FROM torneos";
$result_torneos = $conn->query($sql_torneos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Torneos</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin: 10px;
            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1);
        }
        .card h2 {
            margin-top: 0;
        }
        .card p {
            margin: 5px 0;
        }
        .card button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .card button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php">Inicio</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link">Salir</a></li> <!-- Cambié index.php por logout.php -->
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido principal -->
    <main>
        <h1>Torneos Disponibles</h1>

        <div class="torneos-container">
            <?php
            // Verificar si hay torneos en la base de datos
            if ($result_torneos->num_rows > 0) {
                // Recorrer los torneos y mostrarlos en tarjetas
                while ($torneo = $result_torneos->fetch_assoc()) {
                    echo "<div class='card'>";
                    echo "<h2>Torneo: " . htmlspecialchars($torneo['nombre']) . "</h2>";
                    echo "<p>Fecha de inicio: " . htmlspecialchars($torneo['fecha_inicio']) . "</p>";
                    echo "<p>Fecha de fin: " . htmlspecialchars($torneo['fecha_fin']) . "</p>";
                    echo "<a href='ver_equipos.php?torneo_id=" . intval($torneo['torneo_id']) . "'><button>Ver Equipos</button></a>";
                    echo "</div>";
                }
            } else {
                // Mensaje si no hay torneos
                echo "<p>No hay torneos registrados.</p>";
            }
            ?>
        </div>
    </main>

    <?php $conn->close(); // Cerrar la conexión a la base de datos ?>
</body>
</html>
