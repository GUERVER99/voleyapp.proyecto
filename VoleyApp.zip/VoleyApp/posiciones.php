<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Posiciones</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .navbar {
            background-color: #333;
        }
        .navbar-nav {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
        }
        .nav-item {
            margin: 0 15px;
        }
        .nav-link, .navbar-brand {
            color: white;
            text-decoration: none;
        }
        .nav-link:hover, .navbar-brand:hover {
            text-decoration: underline;
        }
        h1 {
            margin: 20px 0;
        }
        .tabla-posiciones {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        label {
            margin-right: 10px;
        }
        select {
            padding: 5px;
            margin-right: 10px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        footer {
            text-align: center;
            padding: 10px 0;
            background-color: #4CAF50;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php" class="navbar-brand">Inicio</a></li>
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="index.php" class="navbar-brand">Salir</a></li>
                </ul>
            </div>
        </nav>
        <h1>Tabla de Posiciones</h1>
    </header>

    <section class="tabla-posiciones">
        <form method="GET" action="">
            <label for="torneo">Seleccionar Torneo:</label>
            <select name="torneo_id" id="torneo" required>
                <?php
                // Conexión a la base de datos
                $servername = "localhost"; 
                $username = "root"; 
                $password = ""; 
                $dbname = "torneos_volley"; 

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Comprobar conexión
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Obtener torneos
                $sql_torneos = "SELECT torneo_id, nombre FROM torneos";
                $result_torneos = $conn->query($sql_torneos);

                if ($result_torneos->num_rows > 0) {
                    while ($torneo = $result_torneos->fetch_assoc()) {
                        echo "<option value='" . htmlspecialchars($torneo['torneo_id']) . "'>" . htmlspecialchars($torneo['nombre']) . "</option>";
                    }
                } else {
                    echo "<option value=''>No hay torneos disponibles</option>";
                }

                $conn->close();
                ?>
            </select>
            <button type="submit">Ver Tabla de Posiciones</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Equipo</th>
                    <th>Partidos Jugados</th>
                    <th>Partidos Ganados</th>
                    <th>Partidos Perdidos</th>
                    <th>Sets Ganados</th>
                    <th>Sets Perdidos</th>
                    <th>Diferencia de Sets</th>
                    <th>Puntos</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Reabrimos la conexión para mostrar las posiciones
                if (isset($_GET['torneo_id']) && !empty($_GET['torneo_id'])) {
                    $torneo_id = $_GET['torneo_id'];

                    // Crear conexión
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Conexión fallida: " . $conn->connect_error);
                    }

                    // Obtener equipos asociados al torneo seleccionado
                    $sql = "SELECT equipo_id, nombre_equipo FROM equipos WHERE torneo_id = ?";
                    $stmt_equipo = $conn->prepare($sql);
                    $stmt_equipo->bind_param("i", $torneo_id);
                    $stmt_equipo->execute();
                    $result_equipos = $stmt_equipo->get_result();

                    if ($result_equipos->num_rows > 0) {
                        while ($equipo = $result_equipos->fetch_assoc()) {
                            $equipo_id = $equipo['equipo_id'];
                            $equipo_nombre = $equipo['nombre_equipo'];

                            // Inicializar datos de la tabla
                            $partidos_jugados = 0;
                            $partidos_ganados = 0;
                            $partidos_perdidos = 0;
                            $sets_ganados = 0;
                            $sets_perdidos = 0;
                            $puntos = 0;

                            // Consultar partidos como local
                            $sql_local = "SELECT sets_local, sets_visitante FROM partidos WHERE equipo_local_id = ? AND torneo_id = ?";
                            $stmt_local = $conn->prepare($sql_local);
                            $stmt_local->bind_param("ii", $equipo_id, $torneo_id);
                            $stmt_local->execute();
                            $result_local = $stmt_local->get_result();

                            while ($partido = $result_local->fetch_assoc()) {
                                $sets_local = $partido['sets_local'];
                                $sets_visitante = $partido['sets_visitante'];
                                $partidos_jugados++;

                                // Calcular el resultado
                                if ($sets_local > $sets_visitante) {
                                    $partidos_ganados++;
                                    $puntos += ($sets_local == 3 && $sets_visitante < 2) ? 3 : 2;
                                } else {
                                    $partidos_perdidos++;
                                    $puntos += ($sets_local == 2 && $sets_visitante == 3) ? 1 : 0;
                                }

                                $sets_ganados += $sets_local;
                                $sets_perdidos += $sets_visitante;
                            }
                            $stmt_local->close();

                            // Consultar partidos como visitante
                            $sql_visitante = "SELECT sets_local, sets_visitante FROM partidos WHERE equipo_visitante_id = ? AND torneo_id = ?";
                            $stmt_visitante = $conn->prepare($sql_visitante);
                            $stmt_visitante->bind_param("ii", $equipo_id, $torneo_id);
                            $stmt_visitante->execute();
                            $result_visitante = $stmt_visitante->get_result();

                            while ($partido = $result_visitante->fetch_assoc()) {
                                $sets_local = $partido['sets_local'];
                                $sets_visitante = $partido['sets_visitante'];
                                $partidos_jugados++;

                                // Calcular el resultado
                                if ($sets_visitante > $sets_local) {
                                    $partidos_ganados++;
                                    $puntos += ($sets_visitante == 3 && $sets_local < 2) ? 3 : 2;
                                } else {
                                    $partidos_perdidos++;
                                    $puntos += ($sets_visitante == 2 && $sets_local == 3) ? 1 : 0;
                                }

                                $sets_ganados += $sets_visitante;
                                $sets_perdidos += $sets_local;
                            }
                            $stmt_visitante->close();

                            $diferencia_sets = $sets_ganados - $sets_perdidos;

                            // Mostrar fila de la tabla
                            echo "<tr>
                                    <td>" . htmlspecialchars($equipo_nombre) . "</td>
                                    <td>" . htmlspecialchars($partidos_jugados) . "</td>
                                    <td>" . htmlspecialchars($partidos_ganados) . "</td>
                                    <td>" . htmlspecialchars($partidos_perdidos) . "</td>
                                    <td>" . htmlspecialchars($sets_ganados) . "</td>
                                    <td>" . htmlspecialchars($sets_perdidos) . "</td>
                                    <td>" . htmlspecialchars($diferencia_sets) . "</td>
                                    <td>" . htmlspecialchars($puntos) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No hay equipos en este torneo.</td></tr>";
                    }

                    $conn->close();
                }
                ?>
            </tbody>
        </table>
    </section>

    <footer>
        <p>&copy; 2024 - Todos los derechos reservados</p>
    </footer>
</body>
</html>
