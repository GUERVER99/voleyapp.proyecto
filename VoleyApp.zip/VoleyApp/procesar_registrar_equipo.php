<?php
include('database.php'); // Conectar a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $nombre_equipo = mysqli_real_escape_string($conn, $_POST['nombre_equipo']);
    $torneo_id = $_POST['torneo_id'];

    // Verificar si ya existe un equipo con el mismo nombre en el mismo torneo
    $check_query = "SELECT * FROM equipos WHERE nombre = '$nombre_equipo' AND torneo_id = '$torneo_id'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        // Si el equipo ya existe, no se inserta y se muestra un mensaje de error
        $message = "Error: El equipo '$nombre_equipo' ya está registrado en este torneo.";
    } else {
        // Consulta SQL para insertar un nuevo equipo si no hay duplicados
        $query = "INSERT INTO equipos (nombre, torneo_id) VALUES ('$nombre_equipo', '$torneo_id')";

        if ($conn->query($query) === TRUE) {
            $message = "Equipo registrado exitosamente.";
        } else {
            $message = "Error: " . $query . "<br>" . $conn->error;
        }
    }

    // Cerrar la conexión
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de Registro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="home.php" class="navbar-brand">Inicio</a>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="equipos.php" class="nav-link">Ver Equipos</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Resultado del Registro</h1>
        <p><?php echo $message; ?></p>
        <a href="registrar_equipo.php">Registrar Otro Equipo</a> | 
        <a href="equipos.php">Ver Todos los Equipos</a> | 
        <a href="home.php">Volver a la Página Principal</a>
    </main>
</body>
</html>
