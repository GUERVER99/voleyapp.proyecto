<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Partidos Programados</title>
    <style>
        /* General */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }

        h1 {
            font-size: 2em;
            margin: 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
            background-color: #007bff;
            margin: 0;
        }

        nav ul li {
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            padding: 10px 15px;
            display: block;
            transition: background-color 0.3s;
        }

        nav ul li a:hover {
            background-color: #0056b3;
        }

        /* Estilos de tabla */
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #007bff;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        /* Estilos de sección de programación */
        section h2 {
            text-align: center;
            margin-top: 20px;
        }

        form {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        form label {
            display: block;
            margin-bottom: 10px;
        }

        form select, form input, form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        form button:hover {
            background-color: #0056b3;
        }

    </style>
</head>
<body>
    <header>
        <h1>Partidos Programados por Torneos</h1>
    </header>

    <nav>
        <ul>
            <li><a href="crear_torneo.php">Crear Torneo</a></li>
            <li><a href="admin_torneos.php">Ver torneos</a></li>
            <li><a href="gestionar_equipos.php">Gestionar Equipos</a></li>
            <li><a href="gestionar_usuarios.php">Gestionar Usuarios</a></li>
            <li><a href="ver_partidos.php">Ver Partidos Programados</a></li>
            <li><a href="logout.php">Salir</a></li>
        </ul>
    </nav>

    <section>
        <?php
        // Conexión a la base de datos
        $servername = "localhost"; // Cambia si es necesario
        $username = "root"; // Cambia si es necesario
        $password = ""; // Cambia si es necesario
        $dbname = "torneos_volley"; // Cambia al nombre de tu base de datos

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consulta para obtener los torneos
        $sql_torneos = "SELECT torneo_id, nombre FROM torneos";
        $result_torneos = $conn->query($sql_torneos);

        // Verificar si hay torneos disponibles
        if ($result_torneos && $result_torneos->num_rows > 0) {
            while ($torneo = $result_torneos->fetch_assoc()) {
                echo "<h2>" . $torneo['nombre'] . "</h2>";

                // Obtener los partidos de este torneo
                $torneo_id = $torneo['torneo_id'];
                $sql_partidos = "SELECT p.partido_id, e1.nombre_equipo AS equipo_local, e2.nombre_equipo AS equipo_visitante, p.fecha, p.sets_local, p.sets_visitante, p.estado 
                                 FROM partidos p 
                                 JOIN equipos e1 ON p.equipo_local_id = e1.equipo_id 
                                 JOIN equipos e2 ON p.equipo_visitante_id = e2.equipo_id 
                                 WHERE p.torneo_id = '$torneo_id' 
                                 ORDER BY p.fecha";
                $result_partidos = $conn->query($sql_partidos);

                if ($result_partidos && $result_partidos->num_rows > 0) {
                    echo "<table>
                            <tr>
                                <th>ID Partido</th>
                                <th>Fecha</th>
                                <th>Equipo Local</th>
                                <th>Equipo Visitante</th>
                                <th>Sets Local</th>
                                <th>Sets Visitante</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>";
                    while ($partido = $result_partidos->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $partido['partido_id'] . "</td>
                                <td>" . $partido['fecha'] . "</td>
                                <td>" . $partido['equipo_local'] . "</td>
                                <td>" . $partido['equipo_visitante'] . "</td>
                                <td>" . $partido['sets_local'] . "</td>
                                <td>" . $partido['sets_visitante'] . "</td>
                                <td>" . $partido['estado'] . "</td>
                                <td>
                                    <a href='subir_resultado.php?id=" . $partido['partido_id'] . "'>Subir Resultado</a>
                                </td>
                              </tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<p>No hay partidos programados para este torneo.</p>";
                }
            }
        } else {
            echo "<p>No hay torneos disponibles.</p>";
        }
        ?>
    </section>

    <!-- Sección para programar partidos aleatorios -->
    <section>
        <h2>Programar Partidos Aleatorios</h2>
        <form action="" method="POST">
            <label for="torneo_id">Seleccionar Torneo:</label>
            <select id="torneo_id" name="torneo_id" required>
                <?php
                // Reiniciar el cursor de resultado
                $result_torneos->data_seek(0); // Volver al principio del resultado

                while ($torneo = $result_torneos->fetch_assoc()) {
                    echo "<option value='" . $torneo['torneo_id'] . "'>" . $torneo['nombre'] . "</option>";
                }
                ?>
            </select>
            <label for="fecha">Fecha y Hora:</label>
            <input type="datetime-local" id="fecha" name="fecha" required>
            <button type="submit" name="programar_partidos">Programar Partidos Aleatorios</button>
        </form>

        <?php
        if (isset($_POST['programar_partidos'])) {
            $torneo_id = intval($_POST['torneo_id']);
            $fecha_partido = $_POST['fecha'];

            // Obtener todos los equipos en el torneo seleccionado
            $sql_equipos = "SELECT equipo_id, nombre_equipo FROM equipos WHERE torneo_id = $torneo_id";
            $result_equipos = $conn->query($sql_equipos);

            if ($result_equipos && $result_equipos->num_rows < 2) {
                echo "<p>No hay suficientes equipos para programar partidos.</p>";
            } else {
                $equipos = [];
                while ($equipo = $result_equipos->fetch_assoc()) {
                    $equipos[] = $equipo['equipo_id'];
                }

                shuffle($equipos);

                for ($i = 0; $i < count($equipos) - 1; $i += 2) {
                    $equipo_local = $equipos[$i];
                    $equipo_visitante = $equipos[$i + 1];

                    $sql_check_partido = "SELECT * FROM partidos WHERE torneo_id = $torneo_id AND fecha = '$fecha_partido'";
                    $result_check = $conn->query($sql_check_partido);

                    if ($result_check->num_rows == 0) {
                        // Insertar el partido en la base de datos
                        $sql_insert = "INSERT INTO partidos (torneo_id, equipo_local_id, equipo_visitante_id, fecha, estado) VALUES ($torneo_id, $equipo_local, $equipo_visitante, '$fecha_partido', 'programado')";
                        if ($conn->query($sql_insert) === TRUE) {
                            echo "<p>Partido programado entre equipo ID $equipo_local y equipo ID $equipo_visitante para la fecha $fecha_partido.</p>";
                        } else {
                            echo "Error: " . $sql_insert . "<br>" . $conn->error;
                        }
                    } else {
                        echo "<p>Ya hay un partido programado para la fecha seleccionada.</p>";
                        break;
                    }
                }
            }
        }
        ?>

    </section>
</body>
</html>
