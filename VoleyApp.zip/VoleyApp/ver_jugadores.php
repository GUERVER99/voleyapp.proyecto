<?php
session_start();

// Conectar a la base de datos
include('database.php');

// Obtener el id del equipo de la URL
$equipo_id = isset($_GET['equipo_id']) ? $_GET['equipo_id'] : 0;

// Verificar si el equipo existe
$sql_equipo = "SELECT * FROM equipos WHERE equipo_id = $equipo_id";
$result_equipo = $conn->query($sql_equipo);

if ($result_equipo->num_rows > 0) {
    $equipo = $result_equipo->fetch_assoc();
    $nombre_equipo = $equipo['nombre_equipo'];
    $usuario_creador_id = $equipo['usuario_id'];
} else {
    echo "Equipo no encontrado.";
    exit;
}

// Obtener los jugadores inscritos en el equipo
$sql_jugadores = "SELECT * FROM jugadores WHERE equipo_id = $equipo_id";
$result_jugadores = $conn->query($sql_jugadores);

// Obtener el ID del usuario actual
$usuario_id = $_SESSION['usuario_id'];

// Verificar si el usuario actual es el creador del equipo
$es_creador = ($usuario_id == $usuario_creador_id);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jugadores en el equipo <?php echo $nombre_equipo; ?></title>
    <link rel="stylesheet" href="style.css"> <!-- Estilos opcionales -->
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="ver_equipos.php?torneo_id=<?php echo $equipo['torneo_id']; ?>">Volver a Equipos</a></li>
                    <li class="nav-item"><a href="logout.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <h1>Jugadores inscritos en el equipo: <?php echo $nombre_equipo; ?></h1>

        <div class="jugadores-container">
            <?php
            if ($result_jugadores->num_rows > 0) {
                echo "<ul>";
                while ($jugador = $result_jugadores->fetch_assoc()) {
                    echo "<li>" . $jugador['nombre'] . " - " . $jugador['posicion'] . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No hay jugadores inscritos en este equipo.</p>";
            }
            ?>
        </div>

        <?php if ($es_creador): ?>
            <!-- Formulario para añadir jugadores solo si el usuario es el creador del equipo -->
            <h2>Añadir nuevo jugador</h2>
            <form action="agregar_jugador.php" method="POST">
                <input type="hidden" name="equipo_id" value="<?php echo $equipo_id; ?>">
                
                <label for="nombre">Nombre del jugador:</label>
                <input type="text" name="nombre" id="nombre" required>
                
                <label for="tipo_documento">Tipo de documento:</label>
                <select name="tipo_documento" id="tipo_documento" required>
                    <option value="CC">Cédula de Ciudadanía</option>
                    <option value="TI">Tarjeta de Identidad</option>
                    <option value="CE">Cédula de Extranjería</option>
                    <!-- Agregar más opciones si es necesario -->
                </select>

                <label for="documento">Número de documento:</label>
                <input type="text" name="documento" id="documento" required>

                <label for="posicion">Posición del jugador:</label>
                <input type="text" name="posicion" id="posicion" required>
                
                <button type="submit">Añadir jugador</button>
            </form>
        <?php endif; ?>
    </main>

    <?php $conn->close(); ?>
</body>
</html>
