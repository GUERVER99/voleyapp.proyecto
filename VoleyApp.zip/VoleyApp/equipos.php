<?php
include('database.php'); // Conectar a la base de datos

// Verificar si 'equipo_id' está definido en la URL
if (isset($_GET['equipo_id']) && !empty($_GET['equipo_id'])) {
    $equipo_id = $_GET['equipo_id'];
    
    // Consulta para obtener los detalles del equipo
    $query_equipo = "SELECT nombre FROM equipos WHERE id = '$equipo_id'";
    $result_equipo = $conn->query($query_equipo);

    // Verificar si se encontró el equipo
    if ($result_equipo->num_rows == 0) {
        die("Equipo no encontrado.");
    }

    $equipo = $result_equipo->fetch_assoc();

    // Consulta para obtener los jugadores inscritos en el equipo
    $query_jugadores = "SELECT nombre, documento_identidad, posicion, estadisticas FROM jugadores WHERE equipo_id = '$equipo_id'";
    $result_jugadores = $conn->query($query_jugadores);
} else {
    // Si 'equipo_id' no está definido o está vacío, mostrar un mensaje de error
    die("ID de equipo no especificado o inválido.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jugadores del Equipo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <a href="index.php" class="navbar-brand">Torneos de Voleibol</a>
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="crear_torneo.php" class="nav-link">Crear Torneo</a></li>
                    <li class="nav-item"><a href="registrar_jugador.php" class="nav-link">Registrar jugador</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="equipos.php" class="nav-link">Ver Equipos</a></li>
                    <li class="nav-item"><a href="home.php" class="navbar-brand">Inicio</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Jugadores del Equipo: <?php echo $equipo['nombre']; ?></h1>
        <table>
            <tr>
                <th>Nombre</th>
                <th>Documento de Identidad</th>
                <th>Posición</th>
                <th>Estadísticas</th>
            </tr>
            <?php if ($result_jugadores->num_rows > 0): ?>
                <?php while ($jugador = $result_jugadores->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $jugador['nombre']; ?></td>
                        <td><?php echo $jugador['documento_identidad']; ?></td>
                        <td><?php echo $jugador['posicion']; ?></td>
                        <td><?php echo $jugador['estadisticas']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No hay jugadores inscritos en este equipo.</td>
                </tr>
            <?php endif; ?>
        </table>

        <a href="javascript:history.back()">Volver a Detalles del Torneo</a>

    </main>

    <?php
    // Cerrar la conexión a la base de datos
    $conn->close();
    ?>
</body>
</html>
