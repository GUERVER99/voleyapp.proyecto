<?php
session_start();

$error_message = "";

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('database.php'); // Conectar a la base de datos

    // Obtener los datos del formulario
    $nombre_equipo = trim($_POST['nombre_equipo']);
    $torneo_id = intval($_POST['torneo_id']); // Asegurarse de que 'torneo_id' sea un número entero
    $usuario_id = $_SESSION['user_id']; // Obtener el ID del usuario de la sesión

    // Verificar si ya existe un equipo con el mismo nombre en el mismo torneo
    $check_query = "SELECT * FROM equipos WHERE nombre_equipo = ? AND torneo_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("si", $nombre_equipo, $torneo_id);
    $stmt->execute();
    $check_result = $stmt->get_result();

    if ($check_result->num_rows > 0) {
        $error_message = "Error: El equipo '$nombre_equipo' ya está registrado en este torneo.";
    } else {
        // Consulta SQL para insertar un nuevo equipo si no hay duplicados
        $query = "INSERT INTO equipos (nombre_equipo, torneo_id, usuario_id) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sii", $nombre_equipo, $torneo_id, $usuario_id);

        if ($stmt->execute()) {
            header("Location: ver_torneos.php"); // Redirigir a la página de ver equipos
            exit;
        } else {
            $error_message = "Error al insertar el equipo: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Equipo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }
        .navbar {
            display: flex;
            justify-content: center;
            align-items: center; /* Centramos verticalmente las opciones */
        }
        .navbar-nav {
            list-style-type: none;
            padding: 0;
            display: flex; /* Aseguramos que las opciones estén en fila */
        }
        .nav-item {
            margin: 0 15px; /* Espaciado horizontal entre las opciones */
        }
        .nav-link {
            color: #fff;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: background 0.3s;
        }
        .nav-link:hover {
            background-color: #555;
        }
        main {
            padding: 20px;
            background-color: #fff;
            max-width: 800px;
            margin: 20px auto;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            margin-top: 20px;
        }
        label {
            margin-bottom: 5px;
        }
        input[type="text"],
        select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        button {
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php" class="nav-link">Inicio</a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Registrar Nuevo Equipo</h1>
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <form action="registrar_equipo.php" method="POST">
            <label for="nombre_equipo">Nombre del Equipo:</label>
            <input type="text" id="nombre_equipo" name="nombre_equipo" required>
            
            <label for="torneo_id">Seleccionar Torneo:</label>
            <select id="torneo_id" name="torneo_id" required>
                <?php
                // Conectar a la base de datos
                include('database.php');

                // Consulta para obtener todos los torneos
                $query = "SELECT torneo_id, nombre FROM torneos";
                $result = $conn->query($query);

                // Verificar si la consulta tuvo éxito
                if (!$result) {
                    die("Error en la consulta: " . $conn->error);
                }

                // Verificar si se encontraron torneos
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['torneo_id'] . "'>" . $row['nombre'] . "</option>";
                    }
                } else {
                    echo "<option value=''>No hay torneos disponibles</option>";
                }
                ?>
            </select>
            <button type="submit">Registrar Equipo</button>
        </form>
    </main>
</body>
</html>
