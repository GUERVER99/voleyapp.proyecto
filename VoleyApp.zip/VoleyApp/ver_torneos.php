<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener todos los torneos
$sql_torneos = "SELECT * FROM torneos";
$result_torneos = $conn->query($sql_torneos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Torneos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Torneos</h1>
        <div class="row">
            <?php
            if ($result_torneos->num_rows > 0) {
                while ($torneo = $result_torneos->fetch_assoc()) {
                    echo "
                        <div class='col-md-4'>
                            <div class='card mb-4'>
                                <div class='card-body'>
                                    <h5 class='card-title'>{$torneo['nombre']}</h5>
                                    <p class='card-text'>Fecha de inicio: {$torneo['fecha_inicio']}</p>
                                    <p class='card-text'>Fecha de fin: {$torneo['fecha_fin']}</p>
                                    <a href='ver_equipos.php?id_torneo={$torneo['id']}' class='btn btn-primary'>Ver Equipos</a>
                                </div>
                            </div>
                        </div>";
                }
            } else {
                echo "<p>No hay torneos registrados.</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>
