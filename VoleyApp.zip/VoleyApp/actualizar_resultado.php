<?php
// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$partido_id = $_POST['partido_id'];
$sets_local = $_POST['sets_local'];
$sets_visitante = $_POST['sets_visitante'];
$estado = $_POST['estado'];

// Actualizar resultado y estado del partido
$sql = "UPDATE partidos SET sets_local='$sets_local', sets_visitante='$sets_visitante', estado='$estado' WHERE id='$partido_id'";

if ($conn->query($sql) === TRUE) {
    echo "Resultado subido exitosamente.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
