<?php
// Incluir archivo de conexión a la base de datos
include 'database.php'; // Conexión a la base de datos

// Obtener los últimos 5 partidos finalizados con nombres de equipos y torneos
$sql_finalizados = "
SELECT p.fecha, p.sets_local, p.sets_visitante, p.estado, el.nombre_equipo AS equipo_local, ev.nombre_equipo AS equipo_visitante, t.nombre AS nombre_torneo
FROM partidos p
JOIN equipos el ON p.equipo_local_id = el.equipo_id
JOIN equipos ev ON p.equipo_visitante_id = ev.equipo_id
JOIN torneos t ON p.torneo_id = t.torneo_id
WHERE p.estado = 'Finalizado' 
ORDER BY p.fecha DESC 
LIMIT 5";

$result_finalizados = $conn->query($sql_finalizados);

// Obtener los próximos 5 partidos pendientes con nombres de equipos y torneos
$sql_pendientes = "
SELECT p.fecha, el.nombre_equipo AS equipo_local, ev.nombre_equipo AS equipo_visitante, t.nombre AS nombre_torneo
FROM partidos p
JOIN equipos el ON p.equipo_local_id = el.equipo_id
JOIN equipos ev ON p.equipo_visitante_id = ev.equipo_id
JOIN torneos t ON p.torneo_id = t.torneo_id
WHERE p.estado = 'Pendiente' 
ORDER BY p.fecha ASC 
LIMIT 5";
$result_pendientes = $conn->query($sql_pendientes);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Torneos de Voleibol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        header {
            background: #333;
            color: #fff;
            padding: 10px 0;
        }
        .navbar {
            display: flex;
            justify-content: center;
        }
        .navbar-nav {
            list-style: none;
            padding: 0;
        }
        .nav-item {
            display: inline;
            margin: 0 15px;
        }
        .nav-link {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }
        .nav-link:hover {
            text-decoration: underline;
        }
        main {
            margin-top: 20px;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #f2f2f2;
        }
        .partidos-finalizados, .proximos-partidos {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="ver_torneosuser.php" class="nav-link">Torneos</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="calendario.php" class="nav-link">Calendario</a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Bienvenido a la Gestión de Torneos de Voleibol</h1>
        <p>Selecciona una opción del menú para comenzar.</p>

        <!-- Mostrar partidos finalizados -->
        <section>
            <h2>Últimos Partidos Finalizados</h2>
            <?php if ($result_finalizados->num_rows > 0): ?>
                <div class="partidos-finalizados">
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Equipo Local</th>
                                <th>Sets Local</th>
                                <th>Sets Visitante</th>
                                <th>Equipo Visitante</th>
                                <th>Torneo</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result_finalizados->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date("d/m/Y", strtotime($row['fecha'])); ?></td>
                                    <td><?php echo $row['equipo_local']; ?></td>
                                    <td><?php echo $row['sets_local']; ?></td>
                                    <td><?php echo $row['sets_visitante']; ?></td>
                                    <td><?php echo $row['equipo_visitante']; ?></td>
                                    <td><?php echo $row['nombre_torneo']; ?></td>
                                    <td><?php echo $row['estado']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No hay partidos finalizados.</p>
            <?php endif; ?>
        </section>

        <!-- Mostrar próximos partidos pendientes -->
        <section>
            <h2>Próximos Partidos</h2>
            <?php if ($result_pendientes->num_rows > 0): ?>
                <div class="proximos-partidos">
                    <table>
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Equipo Local</th>
                                <th>Equipo Visitante</th>
                                <th>Torneo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result_pendientes->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date("d/m/Y", strtotime($row['fecha'])); ?></td>
                                    <td><?php echo date("H:i", strtotime($row['fecha'])); ?></td> <!-- Mostrar hora -->
                                    <td><?php echo $row['equipo_local']; ?></td>
                                    <td><?php echo $row['equipo_visitante']; ?></td>
                                    <td><?php echo $row['nombre_torneo']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No hay próximos partidos.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>

<?php
$conn->close(); // Cerrar la conexión a la base de datos
?>
