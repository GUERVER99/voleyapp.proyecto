<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) { // Cambiado de 'id' a 'user_id' según tu código anterior
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario de Partidos</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        header {
            background-color: #007BFF;
            color: white;
            padding: 10px 0;
        }

        .navbar {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .navbar-nav {
            list-style: none;
            padding: 0;
            display: flex;
        }

        .nav-item {
            margin: 0 15px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
        }

        .nav-link:hover {
            text-decoration: underline;
        }

        h1 {
            text-align: center;
            margin: 20px 0;
        }

        .calendario {
            margin: 20px auto;
            width: 80%;
            max-width: 800px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            flex: 1; /* Permite que la sección de calendario ocupe el espacio disponible */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background-color: #007BFF;
            color: white;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="home.php" class="navbar-brand">Inicio</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="posiciones.php" class="nav-link">Posiciones</a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
        <h1>Calendario de Partidos</h1>
    </header>

    <section class="calendario">
        <table border="1">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Equipo Local</th>
                    <th>Equipo Visitante</th>
                    <th>Resultado</th>
                    <th>Torneo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conexión a la base de datos
                $conn = new mysqli('localhost', 'root', '', 'torneos_volley');
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Consulta para obtener los partidos junto con los torneos
                $sql = "SELECT p.fecha, el.nombre_equipo AS equipo_local, ev.nombre_equipo AS equipo_visitante, 
                        p.sets_local, p.sets_visitante, p.estado, t.nombre, t.torneo_id
                        FROM partidos p
                        JOIN equipos el ON p.equipo_local_id = el.equipo_id
                        JOIN equipos ev ON p.equipo_visitante_id = ev.equipo_id
                        JOIN torneos t ON p.torneo_id = t.torneo_id
                        ORDER BY p.fecha ASC";

                $result = $conn->query($sql);

                if (!$result) {
                    die("Error en la consulta: " . $conn->error);
                }

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . date("d/m/Y", strtotime($row['fecha'])) . "</td>
                                <td>" . $row['equipo_local'] . "</td>
                                <td>" . $row['equipo_visitante'] . "</td>
                                <td>";

                        // Verificar si el partido ha finalizado
                        if ($row['estado'] === 'Finalizado') {
                            echo $row['sets_local'] . " - " . $row['sets_visitante'];
                        } else {
                            echo "Pendiente";
                        }

                        echo "</td>
                                <td><a href='torneo.php?torneo_id=" . $row['torneo_id'] . "'>" . $row['nombre'] . "</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hay partidos registrados.</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </section>

    <footer>
        <p>&copy; 2024 Dusport - Fedevolei Colombia</p>
    </footer>
</body>
</html>
