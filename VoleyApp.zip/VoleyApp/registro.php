<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Verificar que las contraseñas coinciden
    if ($password !== $confirm_password) {
        echo "<p class='text-red-500'>Las contraseñas no coinciden.</p>";
        exit;
    }

    // Conectar a la base de datos
    $conn = new mysqli('localhost', 'root', '', 'torneos_volley');
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Encriptar la contraseña
    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    $sql_check = "SELECT * FROM usuarios WHERE email = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "<p class='text-red-500'>El email ya está registrado.</p>";
        exit;
    }

    // Insertar el usuario en la base de datos
    $sql = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'usuario')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nombre, $email, $password_hashed);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit;
    } else {
        echo "<p class='text-red-500'>Error en el registro: " . $conn->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white rounded-lg shadow-lg p-8 max-w-sm w-full">
        <h1 class="text-2xl font-semibold mb-4 text-center">Registro de Usuario</h1>
        <form action="" method="POST">
            <label for="nombre" class="block text-sm font-medium text-gray-700">Nombre:</label>
            <input type="text" name="nombre" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 focus:outline-none">

            <label for="email" class="block text-sm font-medium text-gray-700 mt-4">Email:</label>
            <input type="email" name="email" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 focus:outline-none">

            <label for="password" class="block text-sm font-medium text-gray-700 mt-4">Contraseña:</label>
            <input type="password" name="password" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 focus:outline-none">

            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mt-4">Confirmar Contraseña:</label>
            <input type="password" name="confirm_password" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 focus:outline-none">

            <input type="submit" value="Registrarse" class="mt-6 w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200">
        </form>
    </div>
</body>
</html>
