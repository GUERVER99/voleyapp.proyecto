<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestión de Torneos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Administrar Torneos</h1>
    <form action="crear_torneo.php" method="POST">
        <h2>Crear Torneo</h2>
        <label for="nombre">Nombre del Torneo:</label>
        <input type="text" id="nombre" name="nombre" required>
        <label for="fecha_inicio">Fecha de Inicio:</label>
        <input type="date" id="fecha_inicio" name="fecha_inicio" required>
        <label for="fecha_fin">Fecha de Fin:</label>
        <input type="date" id="fecha_fin" name="fecha_fin" required>
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion"></textarea>
        <button type="submit">Crear Torneo</button>
    </form>

    <form action="registrar_equipo.php" method="POST">
        <h2>Registrar Equipo</h2>
        <label for="nombre_equipo">Nombre del Equipo:</label>
        <input type="text" id="nombre_equipo" name="nombre_equipo" required>
        <label for="torneo_id">Torneo:</label>
        <select id="torneo_id" name="torneo_id" required>
            <?php
            // Conectar a la base de datos
            include('database.php');
            
            // Consulta para obtener todos los torneos
            $query = "SELECT id, nombre FROM torneos";
            $result = $conn->query($query);
            
            // Verificar si la consulta tuvo éxito
            if (!$result) {
                die("Error en la consulta: " . $conn->error);
            }
            
            // Verificar si se encontraron torneos
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
                }
            } else {
                echo "<option value=''>No hay torneos disponibles</option>";
            }
            
            // Cerrar la conexión a la base de datos
            $conn->close();
            ?>
            
        </select>
        <button type="submit">Registrar Equipo</button>
    </form>
</body>
</html>
