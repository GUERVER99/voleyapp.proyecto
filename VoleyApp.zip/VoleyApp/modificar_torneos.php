<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "torneos_volley";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID del torneo
if (isset($_GET['id'])) {
    $torneo_id = $_GET['id'];

    // Obtener los datos del torneo
    $sql_torneo = "SELECT * FROM torneos WHERE torneo_id = $torneo_id";
    $result_torneo = $conn->query($sql_torneo);
    $torneo = $result_torneo->fetch_assoc();
} else {
    echo "No se ha especificado un torneo.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];

    // Verificar si se ha subido una nueva imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == UPLOAD_ERR_OK) {
        // Leer el contenido del archivo
        $imagen = file_get_contents($_FILES['imagen']['tmp_name']);
        $imagenBlob = $imagen; // Guardar imagen como BLOB

        // Consulta para actualizar el torneo
        $stmt = $conn->prepare("UPDATE torneos SET nombre = ?, fecha_inicio = ?, fecha_fin = ?, imagen = ? WHERE torneo_id = ?");
        $stmt->bind_param("ssssi", $nombre, $fecha_inicio, $fecha_fin, $imagenBlob, $torneo_id);
    } else {
        // Solo actualizar nombre, fecha de inicio y fecha de fin
        $stmt = $conn->prepare("UPDATE torneos SET nombre = ?, fecha_inicio = ?, fecha_fin = ? WHERE torneo_id = ?");
        $stmt->bind_param("sssi", $nombre, $fecha_inicio, $fecha_fin, $torneo_id);
    }

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Torneo modificado exitosamente.";
        header("Location: admin_torneos.php");
        exit;
    } else {
        echo "Error al modificar el torneo.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Torneo</title>
    <link rel="stylesheet" href="style.css"> <!-- Estilos opcionales -->
</head>
<body>
    <h1>Modificar Torneo</h1>
    <form action="modificar_torneos.php?id=<?php echo $torneo['torneo_id']; ?>" method="POST" enctype="multipart/form-data">
        <label for="nombre">Nombre del Torneo:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo $torneo['nombre']; ?>" required>
        <br>
        <label for="fecha_inicio">Fecha de Inicio:</label>
        <input type="date" id="fecha_inicio" name="fecha_inicio" value="<?php echo $torneo['fecha_inicio']; ?>" required>
        <br>
        <label for="fecha_fin">Fecha de Fin:</label>
        <input type="date" id="fecha_fin" name="fecha_fin" value="<?php echo $torneo['fecha_fin']; ?>" required>
        <br>
        <label for="imagen">Imagen del Torneo:</label>
        <input type="file" id="imagen" name="imagen" accept="image/*">
        <br>
        <button type="submit">Modificar Torneo</button>
    </form>
    <a href="admin_torneos.php">Volver a la lista de torneos</a>
</body>
</html>
