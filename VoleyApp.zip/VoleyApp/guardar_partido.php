<?php
$equipo_local = $_POST['equipo_local'];
$equipo_visitante = $_POST['equipo_visitante'];
$sets_local = $_POST['sets_local'];
$sets_visitante = $_POST['sets_visitante'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];

$conn = new mysqli('localhost', 'root', '', 'torneos_volley');
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Insertar partido en la base de datos
$sql = "INSERT INTO partidos (equipo_local, equipo_visitante, sets_local, sets_visitante, fecha, hora)
        VALUES ('$equipo_local', '$equipo_visitante', '$sets_local', '$sets_visitante', '$fecha', '$hora')";

if ($conn->query($sql) === TRUE) {
    echo "Resultado guardado exitosamente.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
