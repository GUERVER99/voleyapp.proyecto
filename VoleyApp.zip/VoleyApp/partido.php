<form action="actualizar_resultado.php" method="post">
    <label for="partido">Selecciona el Partido:</label>
    <select name="partido_id" id="partido">
        <?php
        // Obtener la lista de partidos para seleccionar
        $sql = "SELECT p.id, el.nombre AS equipo_local, ev.nombre AS equipo_visitante, p.fecha 
                FROM partidos p
                JOIN equipos el ON p.equipo_local = el.id
                JOIN equipos ev ON p.equipo_visitante = ev.id";
        $result = $conn->query($sql);
        
        while($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['equipo_local'] . " vs " . $row['equipo_visitante'] . " (" . $row['fecha'] . ")</option>";
        }
        ?>
    </select>
    
    <label for="sets_local">Sets Ganados por el Equipo Local:</label>
    <input type="number" name="sets_local" id="sets_local" required>
    
    <label for="sets_visitante">Sets Ganados por el Equipo Visitante:</label>
    <input type="number" name="sets_visitante" id="sets_visitante" required>
    
    <button type="submit">Actualizar Resultado</button>
</form>
