<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Torneo</title>
    <style>
        /* General */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Navbar */
        header {
            background-color: #007bff;
            padding: 15px;
        }

        .navbar {
            display: flex;
            justify-content: center;
        }

        .navbar-nav {
            list-style: none;
            padding: 0;
            display: flex;
            gap: 15px;
        }

        .nav-item {
            margin: 0;
        }

        .navbar-brand, .nav-link {
            text-decoration: none;
            color: white;
            font-size: 1.1em;
            padding: 10px 20px;
            background-color: #0056b3;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .navbar-brand:hover, .nav-link:hover {
            background-color: #004080;
        }

        /* Contenido Principal */
        main {
            max-width: 800px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1.1em;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="date"], input[type="file"] {
            padding: 10px;
            font-size: 1em;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            font-size: 1.1em;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header>
        <nav class="navbar">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item"><a href="admin_dashboard.php" class="navbar-brand">Inicio</a></li>
                    <li class="nav-item"><a href="registrar_equipo.php" class="nav-link">Registrar Equipo</a></li>
                    <li class="nav-item"><a href="equipos.php" class="nav-link">Ver Equipos</a></li>
                    <li class="nav-item"><a href="admin_torneos.php" class="nav-link">Ver Torneos</a></li>
                    <li class="nav-item"><a href="admin_posiciones.php" class="nav-link">Posiciones</a></li>
                    <li class="nav-item"><a href="index.php" class="nav-link">Salir</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Contenido Principal -->
    <main>
        <h1>Crear Nuevo Torneo</h1>
        <form action="procesar_crear_torneo.php" method="POST" enctype="multipart/form-data">
            <label for="nombre">Nombre del Torneo:</label>
            <input type="text" id="nombre" name="nombre" required>
            <br>
            <label for="fecha_inicio">Fecha de Inicio:</label>
            <input type="date" id="fecha_inicio" name="fecha_inicio" required>
            <br>
            <label for="fecha_fin">Fecha de Fin:</label>
            <input type="date" id="fecha_fin" name="fecha_fin" required>
            <br>
            <label for="imagen">Imagen del Torneo:</label>
            <input type="file" id="imagen" name="imagen" accept="image/*" required>
            <br>
            <button type="submit">Crear Torneo</button>
        </form>
    </main>
</body>
</html>
